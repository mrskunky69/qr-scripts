-- fxmanifest.lua

game 'rdr3'
fx_version 'adamant'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

client_scripts {
	'client/util-notify.js',
	'client/util-client.lua',
	'client/main-client.lua'
}

server_scripts {
	'server/*.lua'
}

-- ui_page ''

-- files {

-- }
